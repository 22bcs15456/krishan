# Mind Map For Full Stack/ Front End Developers In 2020 





##Front End MindMap

![Mindmap](./junior.png)

![Mindmap](./middle.png)

![Mindmap](./senior.png)


##Full Stack MindMap

![Mindmap](./backend.png)


##Full Stack Mind Map.



[**Back End -Full Stack**](frontenddev.png?raw=true)(image)






## Dedicated Front End Mind Map.

 1. Junior Frontend Developer
[**Junior Frontend Developer**](junior.png?raw=true) (image)


2. Middle Frontend Developer
[**Middle Frontend Developer**](middle.png?raw=true) (image)
3. Senior Frontend Developer
[**Senior Frontend Developer**](senior.png?raw=true) (image)



This content is distributed under CCA v3 license: https://creativecommons.org/licenses/by/3.0/deed.en (added a note to the original repo).


Frontend From: https://github.com/ivan-kleshnin/frontend-mindmaps

And  BAckend from: https://github.com/kamranahmedse/developer-roadmap





