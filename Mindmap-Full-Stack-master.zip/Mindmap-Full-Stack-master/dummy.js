// Tells GitHub this repo is about JavaScript
